package com.retail;

import java.util.Scanner;

public class RetailStore {
	
	private static String customerName;

	public static void main(String[] args) {
		
		CalculateDiscount discount = new CalculateDiscount();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Select Customer type: ");
		System.out.println("1. Worker of the retail store");
        System.out.println("2. Affiliate of the retail store");
        System.out.println("3. Customer for 2 years ");
        System.out.println("4. None of the above");
        System.out.println("5. No discount on Groceries");
        
		int custType=sc.nextInt();
		System.out.println("Enter the Name: ");
		customerName = sc.next();
		System.out.println("Enter your original bill amount details:");
		double billamount=sc.nextDouble();
		
		System.out.println("Total amount payable :" + discount.getDiscount(billamount, custType));
		System.out.println("Thanks for shopping,Have a good day " + customerName );
		sc.close();
			
		}

}

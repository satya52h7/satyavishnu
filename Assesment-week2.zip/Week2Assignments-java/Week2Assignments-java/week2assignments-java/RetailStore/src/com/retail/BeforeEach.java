package com.retail;

public @interface BeforeEach {

}
